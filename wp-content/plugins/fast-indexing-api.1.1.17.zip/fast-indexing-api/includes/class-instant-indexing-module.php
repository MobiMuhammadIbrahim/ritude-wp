<?php

/**
 * Module class loaded by Rank Math. This plugin works independently of
 * Rank Math, so this is just a placeholder.
 */
class RM_GIAPI_Module {}
