			<div class="table-wrapper content wrapper-disabled" id="copyright-section">
				<h3><?php _e('Footer Content', 'cmp-coming-soon-maintenance');?></h3>
				<table class="content">
				<tbody>
					<tr>
						<th><?php _e('Disabled', 'cmp-coming-soon-maintenance');?></th>
						<td>
							<p class="no-margin"><?php _e('Footer is not supported by the selected Theme.', 'cmp-coming-soon-maintenance');?></p>
						</td>
					</tr>

				</tbody>
				</table>
			</div>
