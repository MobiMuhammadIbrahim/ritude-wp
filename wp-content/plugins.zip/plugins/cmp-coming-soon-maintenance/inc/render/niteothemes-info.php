<?php

$html = '
<!-- Build by CMP – Coming Soon Maintenance Plugin by NiteoThemes -->
<!-- Visit plugin page https://wordpress.org/plugins/cmp-coming-soon-maintenance/ -->
<!-- More CMP Themes on https://niteothemes.com -->';