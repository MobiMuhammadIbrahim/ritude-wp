<?php
/**
 * Index file
 *
 * @package     Sinatra
 * @author      Sinatra Team <hello@sinatrawp.com>
 * @since       1.0.0
 */

/* Silence is golden, and we agree. */
