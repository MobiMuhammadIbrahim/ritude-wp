<?php exit(0); ?>
{"user_login":"admin","attempt_time":1633416576,"remote_addr":"103.244.177.10","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/94.0.4606.61 Safari\/537.36"}
{"user_login":"koyal@blogs","attempt_time":1649326904,"remote_addr":"127.0.0.1","user_agent":"Mozilla\/5.0 (Linux; Android 5.0; SM-G900P Build\/LRX21T) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/100.0.4896.75 Mobile Safari\/537.36"}
